import { useRef, useState } from "react";

const photos = [
  {
    src: "https://images.unsplash.com/photo-1555937184-e0e27c09f0e6?auto=format&fit=crop&w=1800&q=85",
    alt: "De Berliner Fernsehturm tijdens het gouden uur",
    credit: "Max Saeling",
    handle: "@maxsaeling",
  },
  {
    src: "https://images.unsplash.com/photo-1604169693370-e4cc769136c4?auto=format&fit=crop&w=1800&q=85",
    alt: "De Fernsehturm vanuit een laag standpunt onder een bewolkte lucht",
    credit: "Chris Reyem",
    handle: "@chris_reyem",
  },
  {
    src: "https://images.unsplash.com/photo-1642764984366-08735318f351?auto=format&fit=crop&w=1800&q=85",
    alt: "De Fernsehturm boven de daken van Berlijn",
    credit: "Norbert Braun",
    handle: "@medion4you",
  },
  {
    src: "https://images.unsplash.com/photo-1597932526087-f80dc479cba0?auto=format&fit=crop&w=1800&q=85",
    alt: "De televisietoren tegen een heldere blauwe lucht",
    credit: "Tim Hüfner",
    handle: "@huefnerdesign",
  },
];

function ArrowIcon({ direction = "right" }: { direction?: "left" | "right" }) {
  return (
    <svg
      aria-hidden="true"
      className={direction === "left" ? "icon icon-left" : "icon"}
      viewBox="0 0 24 24"
    >
      <path d="M5 12h14M14 6l6 6-6 6" />
    </svg>
  );
}

function RouteMap() {
  return (
    <div className="route-map" aria-label="Gestileerde routekaart van Generator Berlin Mitte naar de Fernsehturm">
      <svg viewBox="0 0 700 490" role="img" aria-labelledby="map-title map-description">
        <title id="map-title">Route door Berlin Mitte</title>
        <desc id="map-description">
          Een route vanaf Generator Berlin Mitte via Monbijouplatz en Hackescher Markt naar de
          Fernsehturm bij Alexanderplatz.
        </desc>
        <path className="map-street" d="M-20 88C130 134 221 70 344 101s203 88 378 38" />
        <path className="map-street" d="M96-10c8 137 55 198 36 309S49 442 76 520" />
        <path className="map-street" d="M302-20c-30 137-6 229 53 321s63 138 64 215" />
        <path className="map-street" d="M544-20c-7 103 40 174 18 287s-2 169 91 253" />
        <path className="map-street thin" d="M-20 370c147-45 264-30 369 10s233 48 380-17" />
        <path className="map-street thin" d="M-10 224c146 18 220-45 363-40s216 64 372 18" />
        <path className="route-shadow" d="M102 375C145 342 155 275 209 258s79-19 126-67 115-41 173-4 77 93 100 145" />
        <path className="route-line" d="M102 375C145 342 155 275 209 258s79-19 126-67 115-41 173-4 77 93 100 145" />
        <circle className="map-start" cx="102" cy="375" r="15" />
        <circle className="map-stop" cx="257" cy="239" r="8" />
        <circle className="map-stop" cx="427" cy="170" r="8" />
        <g transform="translate(608 332)">
          <circle className="map-end-ring" r="24" />
          <path className="tower-marker" d="M-8 8 0-36 8 8 0 19Z" />
          <circle className="tower-marker" cy="-18" r="10" />
        </g>
      </svg>
      <span className="map-label map-label-start">Generator<br />Mitte</span>
      <span className="map-label map-label-monbijou">Monbijouplatz</span>
      <span className="map-label map-label-hackescher">Hackescher<br />Markt</span>
      <span className="map-label map-label-end">Fernsehturm</span>
      <span className="map-river">SPREE</span>
      <span className="map-time">± 27 min lopen</span>
    </div>
  );
}

export default function App() {
  const [photoIndex, setPhotoIndex] = useState(0);
  const touchStart = useRef<number | null>(null);

  const setNextPhoto = () => setPhotoIndex((current) => (current + 1) % photos.length);
  const setPreviousPhoto = () =>
    setPhotoIndex((current) => (current - 1 + photos.length) % photos.length);

  return (
    <div className="site-shell">
      <header className="topbar">
        <a href="#top" className="brand" aria-label="Naar boven">
          BERLIN<span>/</span>368
        </a>
        <nav aria-label="Hoofdnavigatie">
          <a href="#waarom">Waarom</a>
          <a href="#info">Info</a>
          <a href="#route">Route</a>
        </nav>
        <a className="nav-ticket" href="#info">Plan bezoek</a>
      </header>

      <main>
        <section id="top" className="hero">
          <img
            className="hero-image"
            src={photos[0].src}
            alt="De Fernsehturm steekt uit boven Berlijn"
          />
          <div className="hero-grain" />
          <div className="hero-copy">
            <div className="hero-kicker"><span /> 52°31′N · 13°24′E</div>
            <h1>
              <span>FERNSEH</span>
              <span className="outline-title">TURM</span>
            </h1>
            <p className="hero-intro">
              <strong>368 meter Berlijn.</strong> Een DDR-icoon, uitzichtpunt en herkenningspunt
              midden in de stad.
            </p>
          </div>
          <div className="height-sticker" aria-label="368 meter hoog">
            <span>HOOGTE</span>
            <strong>368M</strong>
          </div>
          <a className="scroll-cue" href="#intro" aria-label="Scroll naar de introductie">
            <span>Scroll</span>
            <ArrowIcon />
          </a>
          <div className="graffiti hero-tag" aria-hidden="true">ECHT BERLIJN</div>
        </section>

        <div className="ticker" aria-hidden="true">
          <div>
            <span>UITZICHT OP 203 METER</span><b>×</b>
            <span>GEBOUWD IN DE DDR</span><b>×</b>
            <span>MIDDEN OP ALEXANDERPLATZ</span><b>×</b>
            <span>UITZICHT OP 203 METER</span><b>×</b>
          </div>
        </div>

        <section id="intro" className="intro content-grid">
          <div className="section-index">01 / WAT IS HET?</div>
          <div className="intro-copy">
            <p className="lead">
              Geen gewone toren. De Fernsehturm is een <mark>tijdcapsule van beton en staal</mark>{" "}
              die het verhaal van een verdeelde én herenigde stad vertelt.
            </p>
            <div className="columns">
              <p>
                De toren werd tussen 1965 en 1969 gebouwd door de DDR. Het doel was duidelijk:
                laten zien dat Oost-Berlijn modern, technisch sterk en ambitieus was. Vandaag is
                de Fernsehturm juist een symbool voor heel Berlijn.
              </p>
              <p>
                Met 368 meter is dit het hoogste gebouw van Duitsland. De lift brengt je in
                ongeveer 40 seconden naar het uitzichtplatform. Daar kijk je tot tientallen
                kilometers over de stad.
              </p>
            </div>
          </div>
        </section>

        <section id="waarom" className="why-section">
          <div className="graffiti why-tag" aria-hidden="true">WARUM NICHT?</div>
          <div className="content-grid">
            <div className="section-index light">02 / WAAROM GAAN?</div>
            <div>
              <h2>BERLIJN<br /><span>VAN BOVEN.</span></h2>
              <p className="why-intro">
                Je begrijpt pas hoe groot en verschillend Berlijn is wanneer je boven de stad
                staat. Dit is geschiedenis, architectuur en een goed uitzicht in één stop.
              </p>
              <div className="reason-grid">
                <article>
                  <span className="reason-number">01</span>
                  <h3>360° uitzicht</h3>
                  <p>Spot de Brandenburger Tor, de Reichstag, de Spree en de eindeloze stadswijken.</p>
                </article>
                <article className="reason-yellow">
                  <span className="reason-number">02</span>
                  <h3>DDR-design</h3>
                  <p>Bekijk van dichtbij hoe futuristische jaren-zestigarchitectuur eruitziet.</p>
                </article>
                <article>
                  <span className="reason-number">03</span>
                  <h3>Midden in de stad</h3>
                  <p>Combineer je bezoek makkelijk met Alexanderplatz, Hackescher Markt en de Spree.</p>
                </article>
              </div>
            </div>
          </div>
        </section>

        <section id="info" className="info-section">
          <div className="info-heading">
            <div className="section-index">03 / PRAKTISCHE INFO</div>
            <h2>VOORDAT JE<br />OMHOOG GAAT<span>.</span></h2>
          </div>
          <div className="info-board">
            <div className="info-item">
              <span>Openingstijden</span>
              <strong>09:00 — 23:00</strong>
              <small>Dagelijks · laatste toegang kan eerder zijn</small>
            </div>
            <div className="info-item">
              <span>Tickets</span>
              <strong>VANAF €27,50</strong>
              <small>Volwassen standaardticket · online reserveren is slim</small>
            </div>
            <div className="info-item">
              <span>Adres</span>
              <strong>Panoramastraße 1A</strong>
              <small>10178 Berlin · bij Alexanderplatz</small>
            </div>
            <div className="info-item">
              <span>Uitzichtplatform</span>
              <strong>203 METER</strong>
              <small>De lift doet er ongeveer 40 seconden over</small>
            </div>
          </div>
          <div className="info-note">
            <strong>TIP</strong>
            <p>Boek een tijdslot vóór zonsondergang. Dan zie je Berlijn bij daglicht én met alle stadslichten aan.</p>
          </div>
        </section>

        <section id="route" className="route-section">
          <div className="route-heading content-grid">
            <div className="section-index">04 / ROUTE</div>
            <div>
              <p className="eyebrow">STARTPUNT: GENERATOR BERLIN MITTE</p>
              <h2>VAN HOSTEL<br />NAAR <span>HOOGTE.</span></h2>
            </div>
          </div>
          <div className="route-layout">
            <RouteMap />
            <div className="route-options">
              <article>
                <div className="route-mode">
                  <span>01</span>
                  <h3>LOPEN</h3>
                  <strong>± 27 MIN</strong>
                </div>
                <p>
                  Loop via Oranienburger Straße richting Monbijouplatz. Steek door naar Hackescher
                  Markt en volg de toren richting Alexanderplatz. Ongeveer 2,1 kilometer.
                </p>
              </article>
              <article>
                <div className="route-mode">
                  <span>02</span>
                  <h3>TRAM M5</h3>
                  <strong>± 17 MIN</strong>
                </div>
                <p>
                  Loop naar halte Monbijouplatz. Neem tram M5 richting Hohenschönhausen en stap uit
                  bij U Alexanderplatz. Vanaf daar is het nog ongeveer vijf minuten lopen.
                </p>
              </article>
              <a
                className="maps-link"
                href="https://www.google.com/maps/dir/Generator+Berlin+Mitte,+Oranienburger+Stra%C3%9Fe+65,+Berlin/Berliner+Fernsehturm,+Panoramastra%C3%9Fe+1A,+Berlin"
                target="_blank"
                rel="noreferrer"
              >
                Open route in Maps <ArrowIcon />
              </a>
            </div>
          </div>
        </section>

        <section className="gallery-section" aria-labelledby="gallery-title">
          <div className="gallery-head">
            <div>
              <div className="section-index light">05 / KIJK OMHOOG</div>
              <h2 id="gallery-title">DE TOREN<br />IN BEELD.</h2>
            </div>
            <div className="gallery-counter">
              <strong>{String(photoIndex + 1).padStart(2, "0")}</strong>
              <span>/ {String(photos.length).padStart(2, "0")}</span>
            </div>
          </div>
          <div
            className="gallery-frame"
            onTouchStart={(event) => {
              touchStart.current = event.changedTouches[0].clientX;
            }}
            onTouchEnd={(event) => {
              if (touchStart.current === null) return;
              const distance = event.changedTouches[0].clientX - touchStart.current;
              if (Math.abs(distance) > 50) distance > 0 ? setPreviousPhoto() : setNextPhoto();
              touchStart.current = null;
            }}
          >
            {photos.map((photo, index) => (
              <img
                key={photo.src}
                className={index === photoIndex ? "gallery-image active" : "gallery-image"}
                src={photo.src}
                alt={photo.alt}
              />
            ))}
            <div className="photo-credit">
              Foto: {photos[photoIndex].credit} · {photos[photoIndex].handle}
            </div>
            <div className="gallery-controls">
              <button type="button" onClick={setPreviousPhoto} aria-label="Vorige foto">
                <ArrowIcon direction="left" />
              </button>
              <button type="button" onClick={setNextPhoto} aria-label="Volgende foto">
                <ArrowIcon />
              </button>
            </div>
          </div>
          <div className="gallery-dots" aria-label="Kies een foto">
            {photos.map((photo, index) => (
              <button
                type="button"
                key={photo.src}
                className={index === photoIndex ? "active" : ""}
                onClick={() => setPhotoIndex(index)}
                aria-label={`Bekijk foto ${index + 1}`}
                aria-current={index === photoIndex}
              />
            ))}
          </div>
        </section>

        <section className="sources-section">
          <div className="section-index">06 / BRONNEN</div>
          <div>
            <h2>VERDER<br />KIJKEN?</h2>
            <ul>
              <li>
                <a href="https://tv-turm.de/en/plan-your-visit/" target="_blank" rel="noreferrer">
                  Officiële website Berliner Fernsehturm <ArrowIcon />
                </a>
              </li>
              <li>
                <a href="https://www.bvg.de/en" target="_blank" rel="noreferrer">
                  BVG · actuele reisinformatie Berlijn <ArrowIcon />
                </a>
              </li>
              <li>
                <a href="https://unsplash.com/" target="_blank" rel="noreferrer">
                  Fotografie via Unsplash <ArrowIcon />
                </a>
              </li>
            </ul>
            <p className="source-note">
              Prijzen, tijden en OV-routes kunnen wijzigen. Gegevens gecontroleerd in 2026; check
              voor vertrek altijd de officiële websites.
            </p>
          </div>
        </section>
      </main>

      <footer>
        <a href="#top" className="footer-brand">BERLIN<span>/</span>368</a>
        <p>Een korte gids voor studenten in Berlijn.</p>
        <a href="#top" className="back-top">Naar boven ↑</a>
      </footer>
    </div>
  );
}
